/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package studentmanagement.q1;

import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.ByteArrayInputStream;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.InputStream;
        
public class StudentTest {
    
    public StudentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    @Test
    public void testSaveStudent() {
        System.out.println("Testing SaveStudent method.");
        String input="10111\nJ.Bloggs\n19\njbloggs@ymail.com\ndisd\n";
        Scanner scanner = new Scanner(input);
        Student.SaveStudent(scanner);
        assertEquals(1,Student.Students.size());
        Student savedStudent=Student.Students.get(0);
        assertEquals("10111",savedStudent.Id);
        assertEquals("J.Bloggs",savedStudent.name);
        assertEquals("19",savedStudent.age);
        assertEquals("jbloggs@ymail.com",savedStudent.email);
        assertEquals("disd",savedStudent.course);        
    }
    @Test
    public void testSearchStudent() {
        System.out.println("Testing SearchStudent method.");
        Student.Students.clear();
        Student student = new Student("10111","J.Bloggs","19","jbloggs@ymail.com","disd");
        Student.Students.add(student);
        String input="10111\n";
        Scanner scanner = new Scanner(input);
        ByteArrayOutputStream outContent=new ByteArrayOutputStream();
        PrintStream originalOut=System.out;
        System.setOut(new PrintStream(outContent));
        try{
        Student.SearchStudent(scanner);
        String output=outContent.toString();
        assertTrue(output.contains("Student ID: 10111"));
        assertTrue(output.contains("Student NAME: J.Bloggs"));
        assertTrue(output.contains("Student AGE: 19"));
        assertTrue(output.contains("Student EMAIL: jbloggs@ymail.com"));
        assertTrue(output.contains("Student COURSE: disd"));
        }finally{
        System.setOut(originalOut);   
    }
        System.out.println("testSearchStudent test completed");
    }
    @Test
    public void SearchStudent_StudentNotFound(){
        System.out.println("Testing SearchStudent_StudentNotFound method.");
        String input="9999\n";
        Scanner scanner = new Scanner(input);
        Student.StudentReport(scanner);
        System.out.println("SearchStudent_StudentNotFound test complete");
    }
    @Test
    public void testDeleteStudent() {
        System.out.println("Testing DeleteStudent method");
        Student.Students.clear();
         Student student = new Student("10111","J.Bloggs","19","jbloggs@ymail.com","disd");
        Student.Students.add(student);
        String input="10111\nY\n";
        Scanner scanner = new Scanner(input);
        ByteArrayOutputStream outContent=new ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(outContent));
        Student.DeleteStudent(scanner);
        assertFalse(Student.Students.contains(student));
        String output =outContent.toString();
        assertTrue(output.contains("Student with Id: 10111 WAS deleted!"));
        System.setOut(System.out);
    }
    @Test
    
    public void testDeleteStudent_StudentNotFound() {
        System.out.println("Testing DeleteStudent_StudentNotFound method.");
        Student.Students.clear();
        PrintStream originalOut=System.out;
        InputStream originalIn=System.in;
        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        String input="999\nY\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
       try{
           Scanner scanner =new Scanner(System.in);
           Student.DeleteStudent(scanner);
           String output =outputStream.toString().trim();
           String expectedOutput="Student with Student ID: 999 was not found.\n"+
                   "-------------------------------------------------------";
       }finally{
           System.setOut(originalOut);
           System.setIn(originalIn);
       }
        System.out.println("testDeleteStudent_StudentNotFound test completed");
    }
    @Test
    public void testStudentAge_StudentAgeValid() {
        System.out.println("Testing StudentAge_StudentAgeValid method.");
        String input="19\n";
        Scanner scanner = new Scanner(input);
        String age=Student.StudentAge_StudentAgeValid(scanner);
        System.out.println("testStudentAge_StudentAgeValid test complete");
    }
    @Test
    public void testStudentAge_StudentAgeInvalid() {
        System.out.println("Testing StudentAge_StudentAgeInvalid method.");
        String input="15\n";
        InputStream originalIn=System.in;
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();
        PrintStream originalOut=System.out;
        System.setOut(new PrintStream(outputStream));
        try{
            String result=Student.StudentAge_StudentAgeValid(new Scanner(System.in));
            String output=outputStream.toString();
            String expectedPrompt="Enter the student age (must be 16 or older) : ";
            String expectedInvalidAgeMessage="You have entered a incorrect age!!!\n"+
                                             "Please re-enter the student age >>";
            assertEquals(result,"15","The method did not correctly validate the age");
        }finally{
        System.setIn(originalIn);
        System.setOut(originalOut);
    }
        System.out.println("testStudentAge_StudentAgeInvalid test completed");
    }
    @Test
    public void testStudentAge_StudentAgeInvalidCharacter() {
        System.out.println("Testing StudentAge_StudentAgeInvalidCharacter method.");
        String input="abc\n";
        InputStream originalIn=System.in;
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();
        PrintStream originalOut=System.out;
        System.setOut(new PrintStream(outputStream));
        try{
        Scanner scanner = new Scanner(System.in);
        Student.StudentAge_StudentAgeInvalidCharacter(scanner);
        String output=outputStream.toString().trim();
        String expectedOutput="You have entered a incorrect student age!!!\n"+
                              "Please re-enter the student age >>";
        }finally{
            System.setIn(originalIn);
            System.setOut(originalOut);
        }
        System.out.println("testStudentAge_StudentAgeInvalidCharacter test complete");
    }
    @Test
    public void testStudentReport() {
        System.out.println("StudentReport");
        Scanner scanner = null;
        Student.StudentReport(scanner);
    }
    @Test
    public void testExitStudentApplication() {
        System.out.println("ExitStudentApplication");
        Scanner scanner = null;
        Student.ExitStudentApplication(scanner);    
    }   
}
