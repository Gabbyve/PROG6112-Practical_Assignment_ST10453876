/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagement.q1;

import java.util.Scanner;
//Code Attribution:
//https://www.youtube.com/watch?v=3jMaKlNBjug
//https://www.w3schools.com/java/java_switch.asp
//https://www.w3schools.com/java/java_ref_arraylist.asp
public class StudentManagementQ1 {
public static boolean menuLoop=true;
public static boolean continueLoop=true;
    public static void main(String[] args) {
        boolean continueLoop=true;
        Scanner scanner=new Scanner(System.in);
        while(continueLoop){
            int mainChoice=showMainMenu(scanner);
            switch(mainChoice){
                case 1:
                    while(menuLoop){
                        int taskChoice=menuTask(scanner);
                        switch(taskChoice){
                            case 1:
                               Student.SaveStudent(scanner);
                             break;
                            case 2:
                               Student.SearchStudent(scanner);
                             break;
                            case 3:
                               Student.DeleteStudent(scanner);
                             break;
                            case 4:
                               Student.StudentReport(scanner);
                            break;
                            case 5:
                             Student.ExitStudentApplication(scanner);
                               break;
                            case -1:
                               menuLoop=false;
                               break;
                            default:
                                System.out.println("Invalid choice.Returning to the main menu");
                               menuLoop=false;
                               break;
                        }
                    }
                    break;
                case 2:
                    System.out.println("Exiting");
                    continueLoop=false;
                    break;
                case -1:
                    continueLoop=false;
                    break;
                default:
                    System.out.println("Exiting");
                    continueLoop=false;
                    break;
                    
            }
        
    }
    }
    //Opening menu
     public static int showMainMenu(Scanner scanner){
    int choice=-1;
    try{
                    System.out.println(
                    "Student Management Application\n"+
                    "*************************************************\n"+
                     "Enter (1) to launch menu or any key to exit"
            );
                    choice=Integer.parseInt(scanner.nextLine());
            }catch(NumberFormatException e){
                System.out.println("Exiting");
            
    return -1;
}
    return choice; 
}
     //Menu items
    public static int menuTask(Scanner scanner){
     int choice=-1;
    try{
            System.out.println( 
                    "Please select one of the menu items\n"+
                    "(1)Capture a new student\n"+
                    "(2)Search for a student\n"+
                    "(3)Delete a student\n"+
                    "(4)Print student report\n"+        
                    "(5)Exit Application\n"
            );
            choice=Integer.parseInt(scanner.nextLine());
            }catch(NumberFormatException e){
                System.out.println("Exiting");
                return -1;
}
return choice; 
}     

}