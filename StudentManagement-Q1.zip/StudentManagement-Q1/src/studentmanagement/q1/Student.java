/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagement.q1;

import java.util.Scanner;
import java.util.ArrayList;
public class Student {
 String Id;
 String name;
 String age;
 String email;
String course;
String IdSearch;



  public Student( String Id,String name,String age,String email,String course){
      this.Id=Id;
      this.name=name;
      this.age=age;
      this.email=email;
      this.course=course;
  }
  public static ArrayList<Student> Students =new ArrayList<>();
  //method to determine if student age is valid
  public static String StudentAge_StudentAgeValid(Scanner scanner){
   boolean validAge=false;
         String age="";
         while(!validAge){
         System.out.print("Enter the student age (must be 16 or older ) : ");
         age= scanner.nextLine();
         if(isNumeric(age))//if age is numeric
         {
             validAge=isValidAge(age);
             if(!validAge){
                 StudentAge_StudentAgeInvalid(scanner);
             }
         }else{
             StudentAge_StudentAgeInvalidCharacter(scanner);
         }        
}return age;
}
    public static boolean isNumeric(String str){
return str !=null&&str.matches("\\d+");
}
public static boolean isValidAge(String age){
         try{
             int IntAge=Integer.parseInt(age);
             return IntAge>=16;
        }catch (NumberFormatException e){
             return false;
            }
         } 
//method of the prompt when age is invalid
public static void StudentAge_StudentAgeInvalid(Scanner scanner){
             System.out.println("You have entered a incorrect student age!!!");
             System.out.println("Please re-enter the student age >>");
             }
//method of the prompt when there is an invalid character
public static void StudentAge_StudentAgeInvalidCharacter(Scanner scanner){
             System.out.println("You have entered a incorrect student age!!!");
             System.out.println("Please re-enter the student age >>");
}  
//Option 1=Caaptures new student method
  public static void SaveStudent(Scanner scanner){
      StudentManagementQ1 students = new StudentManagementQ1();
         System.out.println(
                    "Student Management Application\n"+
                    "*************************************************");
         System.out.print("Enter the student ID : ");
         String Id= scanner.nextLine();
         System.out.print("Enter the student name : ");
         String name= scanner.nextLine();
         String age=StudentAge_StudentAgeValid(scanner);
         System.out.print("Enter the student email : ");
         String email= scanner.nextLine();
         System.out.print("Enter the student course : ");
         String course= scanner.nextLine();
         Student student = new Student(Id,name,age,email,course);
         Students.add(student);
         System.out.println("Student information successfully captured!");
         System.out.println("Enter (1) to launch menu or any key to exit");
         
         
}
  //Option 2= Search for student method
  public static void SearchStudent(Scanner scanner){
      System.out.print("Enter the student Id to search : ");
      String IdSearch=scanner.nextLine();
      boolean found = false;
      System.out.println("----------------------------------------------------");
      for(Student student : Student.Students){
          if(student.Id.equals(IdSearch)){
              System.out.println("Student ID: "+student.Id);
              System.out.println("Student NAME: "+student.name);
              System.out.println("Student AGE: "+student.age);
              System.out.println("Student EMAIL: "+student.email);
              System.out.println("Student COURSE: "+student.course);
              System.out.println("----------------------------------------------------");
              found =true;
              break;   
          }
      }
     SearchStudent_StudentNotFound(found,IdSearch); 
}
  //method for when a student cant be found while searching
public static void SearchStudent_StudentNotFound(boolean found,String IdSearch){
   if(!found){
       System.out.println("Student woth Student ID : "+ IdSearch+" was not found");
   }   
      System.out.println("----------------------------------------------------");    
  }
//Option 3=Delete student method
   public static void DeleteStudent(Scanner scanner){
    System.out.println("Enter the student Id to delete : ");
    String IdDelete=scanner.nextLine();
    boolean found=false;
    for(Student student : Student.Students){
      if(student.Id.equals(IdDelete)){ 
       System.out.println("are you sure you want to delete the student with the Id : "+IdDelete+ "?");
       System.out.println("Enter Y(Y) to delete");
       System.out.println("-------------------------------------------------------");
       String Confirm=scanner.nextLine();
       if(Confirm.equalsIgnoreCase("Y")){
           Student.Students.remove(student);
       System.out.println("Student with Id: "+IdDelete+" WAS deleted!");
       System.out.println("-------------------------------------------------------");    
       found=true;
       break;
       }
      } 
    }   
  DeleteStudent_StudentNotFound(found,IdDelete);
}
   //method for when student Id cant be found to delete
   public static void DeleteStudent_StudentNotFound(boolean found,String IdDelete){
     if(!found){
         System.out.println("Student with Student ID: "+IdDelete+" was not found.");
         System.out.println("-------------------------------------------------------");
     }  
   }
     //method 4=Print student report method      
   public static void StudentReport(Scanner scanner){
     if(Student.Students.isEmpty()) {
         System.out.println("No students have been added");
     }else{
         int StudentNumber=1;
         for(Student student : Student.Students){
         System.out.println("Student "+StudentNumber);
       System.out.println("---------------------------------------------------");
             System.out.println("Student ID :" +student.Id);
             System.out.println("Student name :" +student.name);
             System.out.println("Student age :" +student.age);
             System.out.println("Student email :" +student.email);
             System.out.println("Student course :" +student.course);
             System.out.println("---------------------------------------------------");
             StudentNumber++;
         }
     } 
   }
   //Option 5=Exit application method
  public static void ExitStudentApplication(Scanner scanner){
    StudentManagementQ1.menuLoop=false;
    StudentManagementQ1.continueLoop=false;
      System.out.println("Exiting application.");
  }  
}
