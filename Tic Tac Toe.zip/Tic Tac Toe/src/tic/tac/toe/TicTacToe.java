/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tic.tac.toe;
//Code attribution:
//https://www.youtube.com/watch?v=gQb3dE-y1S4
//https://www.youtube.com/watch?v=zbVAU7lK25Q
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
public class TicTacToe {
    static HumanPlay humanPlay;
    static CpuPlay cpuPlay;
    static ArrayList<Integer>CpuPositions=new ArrayList<Integer>(); 
    public static void main(String[] args) {
        char[][]gameBoard={{' ','|',' ','|',' '},
                          {'_','+','_','+','_',},
                          {' ','|',' ','|',' '},
                          {'_','+','_','+','_',},
                          {' ','|',' ','|',' '}
                
        };
        Scanner scan = new Scanner(System.in);
        humanPlay=new HumanPlay('X',scan);
        cpuPlay=new CpuPlay('O');
        PrintGameBoard(gameBoard); 
        
        while(true){
       int PlayerPosition=humanPlay.Move();
        while(humanPlay.getPositions().contains(PlayerPosition)||CpuPositions.contains(PlayerPosition)){
            System.out.println("Choose another position as it is taken");
            PlayerPosition=humanPlay.Move();
        }
        placePiece(gameBoard,PlayerPosition,humanPlay);
        String result=checkWinner();
        if(!result.isEmpty()){
            PrintGameBoard(gameBoard);
            System.out.println(result);
            break;
        }
       
        int CpuPosition=cpuPlay.Move();
         while(humanPlay.getPositions().contains(CpuPosition)||CpuPositions.contains(CpuPosition)){
             CpuPosition=cpuPlay.Move();
         }
        placePiece(gameBoard,CpuPosition,cpuPlay);
        PrintGameBoard(gameBoard);
        result=checkWinner();
        if(!result.isEmpty()){
            System.out.println(result);
            break;
        }
    }
    }
    public static void PrintGameBoard(char[][] gameBoard){
        for(char[] row : gameBoard){
            for(char c:row){
                System.out.print(c);
            }
                System.out.println();
            }
        }
    public static void placePiece(char[][] gameBoard, int position,Player player){
         char symbol=player.getSymbol();  
        
        switch(position){
            case 1:
                gameBoard[0][0]=symbol;
                break;
            case 2:
                gameBoard[0][2]=symbol;
                break;
            case 3:
                gameBoard[0][4]=symbol;
                break;
            case 4:
                gameBoard[2][0]=symbol;
                break;
            case 5:
                gameBoard[2][2]=symbol;
                break;
            case 6:
                gameBoard[2][4]=symbol;
                break;
            case 7:
                gameBoard[4][0]=symbol;
                break;
            case 8:
                gameBoard[4][2]=symbol;
                break;
            case 9:
                gameBoard[4][4]=symbol;
                break;  
            default:
                break;
        }  
    }
    public static String checkWinner (){
     List<List<Integer>>winning=Arrays.asList(
        Arrays.asList(1,2,3),
        Arrays.asList(4,5,6),
        Arrays.asList(7,8,9),
        Arrays.asList(1,4,7),
        Arrays.asList(2,5,8),
        Arrays.asList(3,6,9),
        Arrays.asList(1,5,9),
        Arrays.asList(7,5,3)
        );
        for(List<Integer> condition :winning){
            if(humanPlay.getPositions().containsAll(condition)){
                return "Congrats.You WON!!!";
           }else if(cpuPlay.getPositions().containsAll(condition)){
              return "You lost.Try again";     
           }
        }
            if(humanPlay.getPositions().size()+cpuPlay.getPositions().size()==9){
                return "TIE!";
          }
           
        return"";
    } 
    }
    

