/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tic.tac.toe;

import java.util.ArrayList;

class Player {
 protected char symbol;
 protected ArrayList<Integer>positions;
 
 public Player(char symbol){
     this.symbol=symbol;
     this.positions=new ArrayList<>();
 }
 public char getSymbol(){
     return symbol;
 }
 public ArrayList<Integer>getPositions(){
     return positions;
 }
 public void addPosition(int position){
     positions.add(position);
 }
 public int Move(){
     return 0;
 }
}   

