/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tic.tac.toe;
import java.util.Scanner;
class HumanPlay extends Player{
 private Scanner scanner;
 public HumanPlay(char symbol,Scanner scanner){
     super(symbol);
     this.scanner=scanner;
 }
 public int Move(){
     System.out.println("Enter where you would like to play(1-9)!!!");
     return scanner.nextInt();
 }
}    

