/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tic.tac.toe;

import java.util.Random;
class CpuPlay extends Player {
    private Random random;
    public CpuPlay(char symbol){
        super(symbol);
        this.random=new Random();
    }
    public int Move(){
        return random.nextInt(9)+1;
    }
}

