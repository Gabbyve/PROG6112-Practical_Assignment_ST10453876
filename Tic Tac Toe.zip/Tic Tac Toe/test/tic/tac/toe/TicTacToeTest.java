/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package tic.tac.toe;

import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Asus
 */
public class TicTacToeTest {
    private TicTacToe ticTacToe;
    private char[][]gameBoard;
    public TicTacToeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        ticTacToe=new TicTacToe();
        gameBoard=new char[][]{
                          {' ','|',' ','|',' '},
                          {'_','+','_','+','_',},
                          {' ','|',' ','|',' '},
                          {'_','+','_','+','_',},
                          {' ','|',' ','|',' '}
        };
        TicTacToe.humanPlay=new HumanPlay('X',new Scanner(System.in));
        TicTacToe.cpuPlay=new CpuPlay('O');
        TicTacToe.CpuPositions.clear();
    }
    
    @After
    public void tearDown() {
    }
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        TicTacToe.main(args);
    }

    /**
     * Test of PrintGameBoard method, of class TicTacToe.
     */
    @Test
    public void testPrintGameBoard() {
        TicTacToe.PrintGameBoard(gameBoard);
    }

    @Test
    public void testPlacePiece() {
          TicTacToe.placePiece(gameBoard, 1, TicTacToe.humanPlay);
   
         TicTacToe.placePiece(gameBoard, 1, TicTacToe.cpuPlay); 
    }

    @Test
    public void testCheckWinner() {
        System.out.println("checkWinner");
        String expResult = "";
        String result = TicTacToe.checkWinner();
        assertEquals(expResult, result);

    }
    
}
