/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package tic.tac.toe;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class PlayerTest {
    private Player player;
    public PlayerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        player=new Player('X');
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testGetSymbol() {
        char expectedSymbol='X';
        char resultSymbol=player.getSymbol();
      

    }

    /**
     * Test of getPositions method, of class Player.
     */
    @Test
    public void testGetPositions() {
        ArrayList<Integer> result = player.getPositions();
        

    }

    /**
     * Test of addPosition method, of class Player.
     */
    @Test
    public void testAddPosition() {
        int position = 1;
        player.addPosition(position);
        ArrayList<Integer> result = player.getPositions();
    }

    /**
     * Test of Move method, of class Player.
     */
    @Test
    public void testMove() {
        int result = player.Move();
        assertEquals(0, result);
    }
    
}
