/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package tic.tac.toe;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class HumanPlayTest {
    private HumanPlay humanPlay;
    private Scanner mockScanner;
    public HumanPlayTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        mockScanner=new Scanner("5");
        humanPlay=new HumanPlay('X',mockScanner);
    }
    
    @After
    public void tearDown() {
    }
    
    @Test
    public void testMove() {
       int move=humanPlay.Move();
       assertEquals(5,move);

    }
    
}
