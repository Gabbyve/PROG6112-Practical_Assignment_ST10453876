/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package tic.tac.toe;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Random;
import static tic.tac.toe.TicTacToe.cpuPlay;

/**
 *
 * @author Asus
 */
public class CpuPlayTest {
    
    public CpuPlayTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        cpuPlay=new CpuPlay('O');
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testMove() {
       for (int i=0;i<100;i++){
           int move=cpuPlay.Move();
           assertTrue(move>=1&&move<=9);
           
       }

    }   
}
